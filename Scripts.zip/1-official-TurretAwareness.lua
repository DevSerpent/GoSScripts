local TurretAwareness = MenuElement({type = MENU, id = "TurretAwareness", name = "Turret Ranges", leftIcon = "http://puu.sh/pHKD7/a74aa42c4f.jpg"})
TurretAwareness:MenuElement({id = "Enabled", name = "Enabled", value = true})
TurretAwareness:MenuElement({id = "ShowAlly", name = "Show Ally Turret", value = true, leftIcon = "http://puu.sh/rGoYo/0e0e445743.png"})
TurretAwareness:MenuElement({id = "ShowEnemy", name = "Show Enemy Turret", value = true, leftIcon = "http://puu.sh/rGoYt/5c99e94d8a.png"})
TurretAwareness:MenuElement({id = "Sens", name = "Circle Distance Fade", value = 400, min = 100, max = 2000})
TurretAwareness:MenuElement({id = "DLtT", name = "Draw Line to Target", value = true, leftIcon = "https://puu.sh/wcwx4/a7e91b0767.png"})
TurretAwareness:MenuElement({id = "SHoM", name = "Show Health on Minimap", value = true, leftIcon = "https://puu.sh/wczR0/85cf55106f.png"})



local function TargetIsHero(networkID)
for i = 1, Game.HeroCount() do
	local hero = Game.Hero(i)
	if hero.networkID == networkID then
		return hero
		end
	end
return nil
end


function OnDraw()
if not TurretAwareness.Enabled:Value() then return end
for i = 1, Game.TurretCount() do
	local turret = Game.Turret(i)
	local range = (turret.boundingRadius + 750 + myHero.boundingRadius / 2)
	if turret.valid then
		local max_distance = range + TurretAwareness.Sens:Value()
		if turret.distance <= max_distance then
			if turret.isEnemy then
				if TurretAwareness.ShowEnemy:Value() then
					local alpha = turret.distance < range and 255 or (255 - 255 * (turret.distance-range) / TurretAwareness.Sens:Value())
					if turret.targetID == myHero.networkID then
						Draw.Circle(turret.pos,range, 10, Draw.Color(alpha, 255, 0, 0)); --red, turret is attacking us
						if TurretAwareness.DLtT:Value() then Draw.Line(myHero.pos2D.x,myHero.pos2D.y,turret.pos2D.x,turret.pos2D.y,5,Draw.Color(alpha, 255, 0, 0)) end
					elseif turret.targetID == 0 then
						Draw.Circle(turret.pos,range, 1, Draw.Color(alpha, 255, 0xBF, 0)); --orange, the turret might attack us
					else
					local enemyH = TargetIsHero(turret.targetID);
					if enemyH ~= nil then
						Draw.Circle(turret.pos,range, 10, Draw.Color(alpha, 0, 255, 0)); --green, another champion is tanking for us
						if TurretAwareness.DLtT:Value() then Draw.Line(enemyH.pos2D.x,enemyH.pos2D.y,turret.pos2D.x,turret.pos2D.y,5,Draw.Color(alpha, 0, 255, 0)) end
						else
							Draw.Circle(turret.pos,range, 3, Draw.Color(alpha, 0, 255, 0)); --the turret is attacking minions
						end
					end
				end
			elseif TurretAwareness.ShowAlly:Value() then
				local alpha = turret.distance < range and 255 or (255 - 255 * (turret.distance-range) / TurretAwareness.Sens:Value())
				Draw.Circle(turret.pos,range, 0, Draw.Color(alpha, 0, 0x75, 255)); --blue ally turret
				if turret.targetID > 0 then
					local enemyH = TargetIsHero(turret.targetID);
					if enemyH ~= nil then
						if TurretAwareness.DLtT:Value() then Draw.Line(enemyH.pos2D.x,enemyH.pos2D.y,turret.pos2D.x,turret.pos2D.y,5,Draw.Color(alpha, 0, 0x75, 255)) end
						end
					end
				end
			end
		if TurretAwareness.SHoM:Value() then
			if turret.isEnemy then
				if turret.isTargetableToTeam then
					local hpPercentage = tostring(math.floor((turret.health / turret.maxHealth) * 100)).."%"
					Draw.Text(hpPercentage,10,turret.posMM.x,turret.posMM.y,Draw.Color(255, 255, 255, 255));
					end
				end
			end
		end
	end
end


--PrintChat("Turret awareness by Feretorix loaded.")