--TeamPowerTracker

local teamTracker = MenuElement({id = "ttMenu", name = "TeamPower Tracker", type = MENU ,leftIcon = "http://i.imgur.com/Na9ub6J.png" })
teamTracker:MenuElement({id = "Enabled", name = "Enabled", value = true})
teamTracker:MenuElement({id = "range", name = "Track in X range", value = 5000, min = 2000, max = 15000, step = 250})
teamTracker:MenuElement({id = "tab", name = "Scoreboard Key", key = 9})
	
	
local BG = Sprite("TeamTracker\\TeamTrackerBG.png")
local LINE = Sprite("TeamTracker\\TeamTrackerLine.png")
local LINE2 = Sprite("TeamTracker\\TeamTrackerLine2.png")
local A = Sprite("TeamTracker\\arrow.png")
local midX = Game.Resolution().x/2 - BG.width/2
local w = Game.Resolution().x/4

function OnDraw()
if teamTracker.Enabled:Value() == false then return end
	local aE = 0
	local eE = 0
	local aA = 0
	local eA = 0
	for i = 1, Game.HeroCount() do
		local hero = Game.Hero(i)
		if hero and hero.alive and hero.pos:DistanceTo(myHero.pos) < teamTracker.range:Value() then
			if hero.isEnemy then
				eA = eA + 1
				local m = 1
				if hero.maxMana > 0 then m = (hero.mana/hero.maxMana) end
				eE = eE + (hero.health + hero.armor + hero.magicResist + (hero.totalDamage*(0.65*hero.attackSpeed)*(1+hero.critChance)) + hero.ap*(0.5+m))
			else
				aA = aA + 1
				local m = 1
				if hero.maxMana > 0 then m = (hero.mana/hero.maxMana) end
				aE = aE + (hero.health + hero.armor + hero.magicResist + (hero.totalDamage*(0.65*hero.attackSpeed)*(1+hero.critChance)) + hero.ap*(0.5+m))
			end
		end
	end
	local totalE = aE + eE
	local x = 0
	if teamTracker.tab:Value() then
		x = -w
	end
	Draw.Rect( midX + x - 20, -1, 20, 20, Draw.Color(180,1,1,1))
	Draw.Rect( midX + x + 338, -1, 20, 20, Draw.Color(180,1,1,1))
	Draw.Text(aA,18,midX + x - 20 + 6,-1,Draw.Color(200,0,255,10))
	Draw.Text(eA,18,midX + x + 338 + 6,-1,Draw.Color(255,255,0,10))
	BG:Draw(midX + x,0)
	local Cut = {x = 0, y = 0, w = (338*(aE/totalE)), h = 20}
	LINE2:Draw(midX + x,0)
	LINE:Draw(Cut,midX + x,0)
	local n = math.floor((aE/totalE)*100) - 50
	if n < 45 and n > -45 then
		A:Draw(midX + x + (338*(aE/totalE)) - 4,8)
		if (n >= 5 or n <= -5) then
			Draw.Rect( midX + x + (338*(aE/totalE)) - 10, 11, 20, 20, Draw.Color(180,1,1,1))
		if n > 0 then
			Draw.Text("+",20,midX + x + (338*(aE/totalE)) - 6,10,Draw.Color(255,0,255,10))
		else
			Draw.Text("-",20,midX + x + (338*(aE/totalE)) - 2,10,Draw.Color(255,255,0,10))
		end
		end
	end
end

--PrintChat("PowerTracker by Noddy loaded.")